# AlgDS_Praktikum_Gruppe9


ToDo's:

Leitfaden
- Git repository
- Programmiersprache
- Scrum Modell zur Planung
- Absprache pushen testen etc
- Aufgabenverteilung
- Klassenhirachie
- Gemeinsamer Programmiertermin ?
