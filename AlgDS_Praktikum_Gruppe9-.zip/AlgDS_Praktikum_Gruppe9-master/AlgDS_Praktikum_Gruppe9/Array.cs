﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    abstract class Array : IDictionary
    {

        protected int[] array;

        public Array()
        {
            array = new int[50];

        }

        public bool search(int elem)
        {
            int[] pos = search(elem, array);
            if (pos == null)   
            {
                return false;
            }
            else
            {
                if (pos.Length == 1)
                {
                    Console.WriteLine("Das Element befindet sich auf der Stelle: " + pos[0]);
                }
                else
                {     // indexer aller Elemente ausgeben.
                    Console.Write("Das Element befindet sich auf Positionen: ");
                    for (int i = 0; i < pos.Length; i++)
                    {
                        if (i != pos.Length - 1)
                        {
                            Console.Write(pos[i] + ", ");
                        }
                        else
                        {
                            Console.WriteLine(pos[i]);
                        }
                    }
                }
                return true;
            }

        }
        protected int[] search(int elem, int[] array)
        {
            //     bei MultiSet kann sein, dass eine Zahl sich auf unterschiedlichen Stellen (indexer) befindet,
            //     d.h. wir müssen search als int[] array züruckgeben,
            //     in dem alle indexer stehen, wo diese Zahl gibt,falls elem nicht gefunden ist, ist dann indexer == null
            int[] indexer = null;
            int j = 0;
            int y = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == elem) j++;
            }
            if (j != 0)
            {
                indexer = new int[j];
            }

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == elem)
                {
                    indexer[y++] = i;
                }
            }
            return indexer;
        }
        public void print() 
        {

            if (array[0] != 0)
            {
                int[] neuArray;
                int laenge = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] != 0) laenge++;
                }
                neuArray = new int[laenge];

                for (int i = 0; i < neuArray.Length; i++)
                {
                    neuArray[i] = array[i];
                }
                Console.Write("[");
                for (int i = 0; i < neuArray.Length; i++)
                {
                    if (i != neuArray.Length - 1)
                    {
                        Console.Write(neuArray[i] + " | ");
                    }
                    else
                    {
                        Console.Write(neuArray[i]);
                    }
                }
                Console.WriteLine("]");
            }
            else
            {
                Console.WriteLine("Das Array ist leer!");
            }
        }
        public bool delete(int elem)   
        {
            if (search(elem, array) != null)
            {
                while (search(elem, array) != null)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (elem == array[i])
                        {
                            for (int j = i; j < array.Length - 1; j++)
                            {
                                array[j] = array[j + 1];
                            }
                        }
                    }
                }
                return true;
            }
            return false;
        }
        public abstract bool insert(int elem);
    }
}
