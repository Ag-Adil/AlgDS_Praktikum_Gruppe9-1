﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    class MultiSetUnsortedArray : Array, IMultiSetUnsorted 
    {
        public override bool insert(int elem)
        {

            for (int i = 0; i < array.Length; i++)
            {

                if (array[i] == 0) 
                {
                    array[i] = elem; //Element  in der nächsten freien stelle Einfügen , egal ob das Element Vorhanden ist oder nicht .
                                      
                    return true;
                }
            }

            return false;

        }
    }
}
