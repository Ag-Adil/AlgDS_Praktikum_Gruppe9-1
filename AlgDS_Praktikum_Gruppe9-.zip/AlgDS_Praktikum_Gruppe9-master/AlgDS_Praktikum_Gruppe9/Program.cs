﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Prakikum Gruppe 9");
            Console.WriteLine();
            Programmstart();
        }
        private static void Programmstart()
        {
            Console.Write("Welche Funktion möchten Sie bedienen \n1: MultiSetUnsorted \n2: SetUnsorted \n3: MultiSetSorted \n4: SetSorted \nIhre Eingabe: ");
            string eingabe = Console.ReadLine();
            int auswahl = Convert.ToInt32(eingabe);
            Console.Clear();
            switch (auswahl)
            {
                case 1:
                    TestMultiSetUnsorted();
                    break;
                case 2:
                    TestSetUnsorted();
                    break;
                case 3:
                    TestMultiSetSorted();
                    break;
                case 4:
                    TestSetSorted();
                    break;
                default:
                    break;
            }
            Console.WriteLine();
            Console.ReadKey();
        }
        private static void TestSetSorted()
        {
            Console.Write("Welche Funktion möchten Sie bedienen \n1: LinkedList \n2: Array \n3: BinSearchTree \n4: AVLTree \n5: Treap\nIhre Eingabe: ");
            string eingabe = Console.ReadLine();
            int auswahl = Convert.ToInt32(eingabe);
            Console.Clear();
            switch (auswahl)
            {
                case 1:
                    TestSetSortedLinkedList();
                    break;
                case 2:
                    TestSetSortedArray();
                    break;
                case 3:
                    TestBinSearchTree();
                    break;
                case 4:
                    TestAVLTree();
                    break;
                case 5:
                    TestTreap();
                    break;
                default:
                    break;
            }
        }


        private static void TestMultiSetSorted()
        {
            Console.Write("Welche Funktion möchten Sie bedienen \n1: LinkedList \n2: Array \nIhre Eingabe: ");
            string eingabe = Console.ReadLine();
            int auswahl = Convert.ToInt32(eingabe);
            Console.Clear();
            switch (auswahl)
            {
                case 1:
                    TestMultiSetSortedLinkedList();
                    break;
                case 2:
                    TestMultiSetSortedArray();
                    break;
                default:
                    break;
            }

        }
        private static void TestMultiSetSortedArray()
        {
            MultiSetSortedArray array = new MultiSetSortedArray();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatisches Array Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        array.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        array.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(array.search(auswahl3));
                        break;
                    case 4:
                        array.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll das generierte Array sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            array.insert(rnd.Next(1, 100));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        private static void TestMultiSetUnsortedArray()
        {
            MultiSetUnsortedArray array = new MultiSetUnsortedArray();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatisches Array Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        array.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        array.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(array.search(auswahl3));
                        break;
                    case 4:
                        array.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll das generierte Array sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            array.insert(rnd.Next(1, 100));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        private static void TestSetSortedArray()
        {
            SetSortedArray array = new SetSortedArray();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatisches Array Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        array.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        array.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(array.search(auswahl3));
                        break;
                    case 4:
                        array.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll das generierte Array sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        List<int> rndnumbers = new List<int>();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            int number;
                            do
                            {
                                number = rnd.Next(1, 100);
                            }
                            while (rndnumbers.Contains(number));


                            array.insert(number);
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        private static void TestSetUnsortedArray()
        {
            SetUnsortedArray array = new SetUnsortedArray();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatisches Array Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        array.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        array.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(array.search(auswahl3));
                        break;
                    case 4:
                        array.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll das generierte Array sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        List<int> rndnumbers = new List<int>();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            int number;
                            do
                            {
                                number = rnd.Next(1, 100);
                            }
                            while (rndnumbers.Contains(number));


                            array.insert(number);
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }


        private static void TestSetUnsorted()
        {
            Console.Write("Welche Funktion möchten Sie bedienen \n1: LinkedList \n2: HashTabSepChain \n3: HashTabQuadProb \n4: Array \nIhre Eingabe: ");
            string eingabe = Console.ReadLine();
            int auswahl = Convert.ToInt32(eingabe);
            Console.Clear();
            switch (auswahl)
            {
                case 1:
                    TestSetUnsortedLinkedList();
                    break;
                case 2:
                    TestHashTabSepChain();
                    break;
                case 3:
                    TestHashTabQuadProb();
                    break;
                case 4:
                    TestSetUnsortedArray();
                    break;
                default:
                    break;
            }
        }
        private static void TestMultiSetUnsorted()
        {
            Console.Write("Welche Funktion möchten Sie bedienen \n1: LinkedList \n2: Array \nIhre Eingabe: ");
            string eingabe = Console.ReadLine();
            int auswahl = Convert.ToInt32(eingabe);
            Console.Clear();
            switch (auswahl)
            {
                case 1:
                    TestMultiSetUnsortedLinkedList();
                    break;
                case 2:
                    TestMultiSetUnsortedArray();
                    break;
                default:
                    break;
            }
        }
        public static void TestMultiSetSortedLinkedList()
        {
            MultiSetSortedLinkedList multiSetSortedLinkedList = new MultiSetSortedLinkedList();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        multiSetSortedLinkedList.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        multiSetSortedLinkedList.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(multiSetSortedLinkedList.search(auswahl3));
                        break;
                    case 4:
                        multiSetSortedLinkedList.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            multiSetSortedLinkedList.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestSetSortedLinkedList()
        {
            SetSortedLinkedList setSortedLinkedList = new SetSortedLinkedList();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        setSortedLinkedList.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        setSortedLinkedList.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(setSortedLinkedList.search(auswahl3));
                        break;
                    case 4:
                        setSortedLinkedList.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            setSortedLinkedList.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestSetUnsortedLinkedList()
        {
            SetUnsortedLinkedList setUnsortedLinkedList = new SetUnsortedLinkedList();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        setUnsortedLinkedList.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        setUnsortedLinkedList.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(setUnsortedLinkedList.search(auswahl3));
                        break;
                    case 4:
                        setUnsortedLinkedList.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            setUnsortedLinkedList.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestMultiSetUnsortedLinkedList()
        {
            MultiSetUnsortedLinkedList multiSetUnsortedLinkedList = new MultiSetUnsortedLinkedList();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        multiSetUnsortedLinkedList.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        multiSetUnsortedLinkedList.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(multiSetUnsortedLinkedList.search(auswahl3));
                        break;
                    case 4:
                        multiSetUnsortedLinkedList.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            multiSetUnsortedLinkedList.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestHashTabSepChain()
        {
            HashTabSepChain hashTabSepChain = new HashTabSepChain();
            hashTabSepChain.hilfsfunction();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        hashTabSepChain.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        hashTabSepChain.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(hashTabSepChain.search(auswahl3));
                        break;
                    case 4:
                        hashTabSepChain.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            int zufall = rnd.Next(0, 99);
                            hashTabSepChain.insert(zufall);
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestBinSearchTree()
        {

            BinSearchTree binSearchTree = new BinSearchTree();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatische Baum Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        binSearchTree.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        binSearchTree.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(binSearchTree.search(auswahl3));
                        break;
                    case 4:
                        binSearchTree.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            binSearchTree.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestAVLTree()
        {
            AVLTree binSearchTree = new AVLTree();

            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatische Baum Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        binSearchTree.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        binSearchTree.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(binSearchTree.search(auswahl3));
                        break;
                    case 4:
                        binSearchTree.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            binSearchTree.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
        public static void TestTreap()
        {
            Treap treap = new Treap();


            bool repeat = true;

            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben\n5: Automatische Baum Generieren \n6: Züruck zum Hauptmenü \nIhre Auswahl: ");
                int auswahl = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        treap.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen:");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        treap.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(treap.search(auswahl3));
                        break;
                    case 4:
                        treap.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            treap.insert(rnd.Next(0, 9));
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;


                    default:
                        break;
                }
            }
        }
        public static void TestHashTabQuadProb()
        {
            HashTabQuadProb hashTabQuadProb = new HashTabQuadProb();
            bool repeat = true;
            while (repeat)
            {
                Console.Write("Wählen Sie eine Funktion: \n1: Einfügen\n2: Löschen\n3: Suchen\n4: Ausgeben \n5: Automatische Liste Generieren \n6: Zurück zum Hauptmenü \nIhre Auswahl: ");
                string eingabe = Console.ReadLine();
                int auswahl = Convert.ToInt32(eingabe);
                Console.Clear();
                switch (auswahl)
                {
                    case 1:
                        Console.Write("Welchen Wert wollen Sie Einfügen: ");
                        string eingabe1 = Console.ReadLine();
                        int auswahl1 = Convert.ToInt32(eingabe1);
                        hashTabQuadProb.insert(auswahl1);
                        break;
                    case 2:
                        Console.Write("Welchen Wert wollen Sie Löschen: ");
                        string eingabe2 = Console.ReadLine();
                        int auswahl2 = Convert.ToInt32(eingabe2);
                        hashTabQuadProb.delete(auswahl2);
                        break;
                    case 3:
                        Console.Write("Welchen Wert wollen Sie Suchen: ");
                        string eingabe3 = Console.ReadLine();
                        int auswahl3 = Convert.ToInt32(eingabe3);
                        Console.WriteLine(hashTabQuadProb.search(auswahl3));
                        break;
                    case 4:
                        hashTabQuadProb.print();
                        break;
                    case 5:
                        Console.Write("Wie Lange soll die Generierte Liste sein: ");
                        string eingabe5 = Console.ReadLine();
                        int auswahl5 = Convert.ToInt32(eingabe5);
                        Random rnd = new Random();
                        for (int i = 0; i < auswahl5; i++)
                        {
                            int zufall = rnd.Next(0, 99);
                            hashTabQuadProb.insert(zufall);
                        }
                        break;
                    case 6:
                        Programmstart();
                        break;
                    default:
                        break;
                }
            }
        }
    }
}


