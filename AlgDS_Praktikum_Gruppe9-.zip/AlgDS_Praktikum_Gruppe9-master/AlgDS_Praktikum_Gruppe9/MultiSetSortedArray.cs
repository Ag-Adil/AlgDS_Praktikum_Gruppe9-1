﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    class MultiSetSortedArray : Array, IMultiSetSorted
    {
        public override bool insert(int elem)  
        {
            if (elem != 0)
            {
                if (array[0] == 0)    // Wenn das Array leer ist , dann Element in der ersten Stelle einfügen  
                {
                    array[0] = elem; 
                }
                else
                {
                    int index = 0;
                    if (array[0] >= elem)
                    {
                        index = 0;
                    }
                    else
                    {
                        for (int i = 0; i < array.Length - 1; i++)
                        {
                            if (array[i] < elem && array[i + 1] >= elem)
                            {
                                index = i + 1;
                            }
                            else if (array[i] < elem && array[i] != 0 && array[i + 1] == 0)
                            {
                                index = i + 1;
                            }
                        }
                    }
                    for (int i = array.Length - 1; i >= index; i--)
                    {
                        if (array[i] > 0)
                        {
                            array[i + 1] = array[i]; // die Elemente nach dem position des neuen elementes  werden um 1 nach rechts verschoben.
                        }
                    }
                    for (int i = 0; i < array.Length; i++)
                    {
                        array[index] = elem;      // Elemennt in dem Index einfügen
                    }
                }
                return true;

            }
            return false;
        }
    }
}
