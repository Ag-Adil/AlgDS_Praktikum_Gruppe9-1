﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    class SetUnsortedArray : Array, ISetUnsorted
    {

        public override bool insert(int elem) 
        {
            // Wir suchen erstmal , ob das Element vorahanden ist. Wenn nicht dann Element  Einfügen .
            if (search(elem, array) == null)
            {
                for (int i = 0; i < array.Length; i++)
                {

                    if (array[i] == 0)  // Element  in der nächsten freien stelle Einfügen .
                    {
                        array[i] = elem;
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
