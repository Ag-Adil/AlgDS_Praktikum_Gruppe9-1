﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgDS_Praktikum_Gruppe9
{
    class SetSortedArray : Array, ISetSorted
    {
        public override bool insert(int elem) 
        {
            if (elem != 0)
            {
                if (search(elem, array) == null ) // einfügen nur  wenn das Element in dem Array nicht befindet .
                {
                    if (array[0] == 0)
                    {
                        array[0] = elem;
                    }
                    else
                    {
                        int index = 0;
                        if (array[0] > elem)
                        {
                            index = 0;
                        }
                        else
                        {
                            for (int i = 0; i < array.Length - 1; i++)
                            {
                                if (array[i] < elem && array[i + 1] >= elem)
                                {
                                    index = i + 1;
                                }
                                else if (array[i] < elem && array[i] != 0 && array[i + 1] == 0)
                                {
                                    index = i + 1;
                                }
                            }
                        }
                        for (int i = array.Length - 1; i >= index; i--)
                        {
                            if (array[i] > 0)
                            {
                                array[i + 1] = array[i];
                            }
                        }
                        for (int i = 0; i < array.Length; i++)
                        {
                            array[index] = elem;
                        }
                    }
                    return true;
                }
               
            }
            return false;
        }
    }
}
